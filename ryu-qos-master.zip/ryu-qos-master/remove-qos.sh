sudo ovs-vsctl --all destroy qos
sudo ovs-vsctl --all destroy queue
